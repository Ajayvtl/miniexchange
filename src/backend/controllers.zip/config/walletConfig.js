module.exports = {
    maxWalletsPerUser: 10, // Maximum number of wallets a user can have
};
