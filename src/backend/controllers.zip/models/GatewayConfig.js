const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");

const GatewayConfig = sequelize.define("GatewayConfig", {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    name: { type: DataTypes.STRING(50), allowNull: false, unique: true },
    enabled: { type: DataTypes.TINYINT, defaultValue: 1 }, // 1 = Active, 0 = Disabled
    config: { type: DataTypes.TEXT, allowNull: false }, // Stores JSON API config
}, {
    timestamps: true,
    tableName: "gateway_config",
});

module.exports = GatewayConfig;
