// ✅ Token Blacklist Storage (Global)
const blacklistedTokens = new Set();

module.exports = blacklistedTokens;
